# Conversor de Tabelas Hospitalares
Aplicação local para conversão de textos não estruturados em Excel.

## Como usar:
1. Instale as dependências: `pip install -r requirements.txt`
2. Inicie a aplicação: `python app.py`
3. Acesse no navegador: `http://localhost:5000`

## Estrutura:
- `processors/`: Lógica de extração (Regex/Texto).
- `services/`: Geração de arquivos Excel.
- `static/`: Interface visual (CSS/JS).
