import re
def process(text):
    # Código (8 dígitos) | Descrição (sem valor)
    pattern = r'(\d{8})\s+(.*?)(?=\d{8}|$)'
    matches = re.findall(pattern, text, re.DOTALL)
    return [{"Código": m[0], "Descrição": m[1].strip()} for m in matches]
