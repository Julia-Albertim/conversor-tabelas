import re
def process(text):
    # Simulação da lógica do txt_excl2.py (Código 6-8 digitos + R$)
    pattern = r'(\d{6,8})\s+(.*?)\s+R\$\s*(\d+,\d{2})'
    matches = re.findall(pattern, text, re.DOTALL)
    return [{"Código": m[0], "Procedimento": m[1].strip(), "Valor": m[2]} for m in matches]
