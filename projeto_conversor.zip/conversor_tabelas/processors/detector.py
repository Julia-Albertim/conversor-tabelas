def identify(text):
    if "R$" in text:
        return 'tipo2' if any(len(w) >= 6 and w.isdigit() for w in text.split()) else 'tipo4'
    return 'tipo1'
