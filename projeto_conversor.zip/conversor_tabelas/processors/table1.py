import re
def process(text):
    # Regex: Item (digito) | Descrição | Valor (0,00)
    pattern = r'^(\d+)\s+(.*?)\s+(\d+,\d{2})$'
    data = []
    for line in text.strip().split('\n'):
        match = re.match(pattern, line.strip())
        if match:
            data.append({"Item": match.group(1), "Descrição": match.group(2), "Valor": match.group(3)})
    return data
